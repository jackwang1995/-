﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Main))
        Me.SerialPort1 = New System.IO.Ports.SerialPort(Me.components)
        Me.VectorControlTimer = New System.Windows.Forms.Timer(Me.components)
        Me.TabControlFOC = New System.Windows.Forms.TabControl
        Me.TabQDPI = New System.Windows.Forms.TabPage
        Me.GroupBox5 = New System.Windows.Forms.GroupBox
        Me.Label35 = New System.Windows.Forms.Label
        Me.Label34 = New System.Windows.Forms.Label
        Me.Label23 = New System.Windows.Forms.Label
        Me.Label22 = New System.Windows.Forms.Label
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.Label40 = New System.Windows.Forms.Label
        Me.Label39 = New System.Windows.Forms.Label
        Me.Label38 = New System.Windows.Forms.Label
        Me.Label37 = New System.Windows.Forms.Label
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.TrackBarQKi = New Trackbar.TransparentTrackBar
        Me.TrackBarQ_SP = New Trackbar.TransparentTrackBar
        Me.TrackBarQKp = New Trackbar.TransparentTrackBar
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.RadioButtonManualSpeed = New System.Windows.Forms.RadioButton
        Me.LabelQKp = New System.Windows.Forms.Label
        Me.RadioButtonAutoSpeed = New System.Windows.Forms.RadioButton
        Me.Label7 = New System.Windows.Forms.Label
        Me.LabelQ_SP = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.LabelQKi = New System.Windows.Forms.Label
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.TrackBarDKi = New Trackbar.TransparentTrackBar
        Me.TrackBarD_SP = New Trackbar.TransparentTrackBar
        Me.TrackBarDKp = New Trackbar.TransparentTrackBar
        Me.Label2 = New System.Windows.Forms.Label
        Me.LabelD_SP = New System.Windows.Forms.Label
        Me.Label33 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.LabelDKp = New System.Windows.Forms.Label
        Me.LabelDKi = New System.Windows.Forms.Label
        Me.TabSpeedPID = New System.Windows.Forms.TabPage
        Me.GroupBox10 = New System.Windows.Forms.GroupBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.GroupBox9 = New System.Windows.Forms.GroupBox
        Me.TrackBarSpeedSP = New Trackbar.TransparentTrackBar
        Me.TrackBarSpeedKd = New Trackbar.TransparentTrackBar
        Me.ValueLabelSpeedSP = New System.Windows.Forms.Label
        Me.TrackBarSpeedKi = New Trackbar.TransparentTrackBar
        Me.Label28 = New System.Windows.Forms.Label
        Me.TrackBarSpeedKp = New Trackbar.TransparentTrackBar
        Me.Label27 = New System.Windows.Forms.Label
        Me.LabelSpeedKp = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.LabelSpeedKi = New System.Windows.Forms.Label
        Me.Label24 = New System.Windows.Forms.Label
        Me.LabelSpeedKd = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.TabVectorConrol = New System.Windows.Forms.TabPage
        Me.GroupBox8 = New System.Windows.Forms.GroupBox
        Me.CheckBoxSync = New System.Windows.Forms.CheckBox
        Me.CheckBoxAutoRotate = New System.Windows.Forms.CheckBox
        Me.CheckBoxTransmit = New System.Windows.Forms.CheckBox
        Me.GroupBox7 = New System.Windows.Forms.GroupBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.GroupBox6 = New System.Windows.Forms.GroupBox
        Me.LabelA = New System.Windows.Forms.Label
        Me.LabelB = New System.Windows.Forms.Label
        Me.LabelC = New System.Windows.Forms.Label
        Me.TabParameters = New System.Windows.Forms.TabPage
        Me.Label42 = New System.Windows.Forms.Label
        Me.Label36 = New System.Windows.Forms.Label
        Me.Label43 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.ButtonDivL = New System.Windows.Forms.Button
        Me.ButtonDivR = New System.Windows.Forms.Button
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.LabelTest3 = New System.Windows.Forms.Label
        Me.TrackBarTest3 = New System.Windows.Forms.TrackBar
        Me.LabelTest4 = New System.Windows.Forms.Label
        Me.TrackBarTest4 = New System.Windows.Forms.TrackBar
        Me.LabelTest1 = New System.Windows.Forms.Label
        Me.TrackBarTest1 = New System.Windows.Forms.TrackBar
        Me.LabelTest2 = New System.Windows.Forms.Label
        Me.TrackBarTest2 = New System.Windows.Forms.TrackBar
        Me.LabelPeriodTime = New System.Windows.Forms.Label
        Me.Label32 = New System.Windows.Forms.Label
        Me.Label31 = New System.Windows.Forms.Label
        Me.Label30 = New System.Windows.Forms.Label
        Me.Label29 = New System.Windows.Forms.Label
        Me.Label26 = New System.Windows.Forms.Label
        Me.Label25 = New System.Windows.Forms.Label
        Me.LabelG = New System.Windows.Forms.Label
        Me.LabelF = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.LabelRPM = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Label20 = New System.Windows.Forms.Label
        Me.RadioButtonSensorless = New System.Windows.Forms.RadioButton
        Me.RadioButtonQEI = New System.Windows.Forms.RadioButton
        Me.LabelPower = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.LabelMode = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.LabelTemp = New System.Windows.Forms.Label
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.MenuItemExit = New System.Windows.Forms.ToolStripMenuItem
        Me.EditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ButtonCOM = New System.Windows.Forms.Button
        Me.ButtonLog = New System.Windows.Forms.Button
        Me.ButtonScope = New System.Windows.Forms.Button
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.MenuItemOpen = New System.Windows.Forms.ToolStripMenuItem
        Me.MenuItemSave = New System.Windows.Forms.ToolStripMenuItem
        Me.MenuItemSettings = New System.Windows.Forms.ToolStripMenuItem
        Me.AddScopeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DataloggerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FixedPointToolToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.VectorViewer1 = New FOCinterface.VectorViewer
        Me.ProgressControl4 = New FOCinterface.ProgressControl
        Me.ProgressControl3 = New FOCinterface.ProgressControl
        Me.ProgressControl2 = New FOCinterface.ProgressControl
        Me.ProgressControl1 = New FOCinterface.ProgressControl
        Me.ProgressControlSpeedErr = New FOCinterface.ProgressControl
        Me.ProgressControlSpeedDer = New FOCinterface.ProgressControl
        Me.ProgressControlSpeedInt = New FOCinterface.ProgressControl
        Me.SVPWMControl1 = New FOCinterface.SVPWMControl
        Me.PWM1_actual = New FOCinterface.PWMControl
        Me.PWM2_actual = New FOCinterface.PWMControl
        Me.PWM3_actual = New FOCinterface.PWMControl
        Me.PWM3_virtual = New FOCinterface.PWMControl
        Me.PWM1_virtual = New FOCinterface.PWMControl
        Me.PWM2_virtual = New FOCinterface.PWMControl
        Me.TextBoxOmegaFltrCoef = New FOCinterface.NumericTextBox
        Me.TextBoxSMCMaxError = New FOCinterface.NumericTextBox
        Me.TextBoxSMCgain = New FOCinterface.NumericTextBox
        Me.TextBoxmH = New FOCinterface.NumericTextBox
        Me.TextBoxmOhm = New FOCinterface.NumericTextBox
        Me.TabControlFOC.SuspendLayout()
        Me.TabQDPI.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        CType(Me.TrackBarQKi, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBarQ_SP, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBarQKp, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.TrackBarDKi, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBarD_SP, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBarDKp, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabSpeedPID.SuspendLayout()
        Me.GroupBox10.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        CType(Me.TrackBarSpeedSP, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBarSpeedKd, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBarSpeedKi, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBarSpeedKp, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabVectorConrol.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.TabParameters.SuspendLayout()
        CType(Me.TrackBarTest3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBarTest4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBarTest1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBarTest2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'SerialPort1
        '
        Me.SerialPort1.BaudRate = 115200
        '
        'VectorControlTimer
        '
        Me.VectorControlTimer.Enabled = True
        '
        'TabControlFOC
        '
        Me.TabControlFOC.Controls.Add(Me.TabQDPI)
        Me.TabControlFOC.Controls.Add(Me.TabSpeedPID)
        Me.TabControlFOC.Controls.Add(Me.TabVectorConrol)
        Me.TabControlFOC.Controls.Add(Me.TabParameters)
        Me.TabControlFOC.Location = New System.Drawing.Point(12, 75)
        Me.TabControlFOC.Name = "TabControlFOC"
        Me.TabControlFOC.SelectedIndex = 0
        Me.TabControlFOC.Size = New System.Drawing.Size(798, 653)
        Me.TabControlFOC.TabIndex = 3
        '
        'TabQDPI
        '
        Me.TabQDPI.Controls.Add(Me.GroupBox5)
        Me.TabQDPI.Controls.Add(Me.GroupBox4)
        Me.TabQDPI.Controls.Add(Me.GroupBox3)
        Me.TabQDPI.Controls.Add(Me.GroupBox2)
        Me.TabQDPI.Location = New System.Drawing.Point(4, 22)
        Me.TabQDPI.Name = "TabQDPI"
        Me.TabQDPI.Padding = New System.Windows.Forms.Padding(3)
        Me.TabQDPI.Size = New System.Drawing.Size(790, 627)
        Me.TabQDPI.TabIndex = 4
        Me.TabQDPI.Text = "Q&D PI controllers"
        Me.TabQDPI.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Label35)
        Me.GroupBox5.Controls.Add(Me.Label34)
        Me.GroupBox5.Controls.Add(Me.Label23)
        Me.GroupBox5.Controls.Add(Me.Label22)
        Me.GroupBox5.Controls.Add(Me.VectorViewer1)
        Me.GroupBox5.Location = New System.Drawing.Point(362, 3)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(422, 421)
        Me.GroupBox5.TabIndex = 343
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Vector graph"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.ForeColor = System.Drawing.Color.Purple
        Me.Label35.Location = New System.Drawing.Point(352, 48)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(39, 13)
        Me.Label35.TabIndex = 344
        Me.Label35.Text = "Vq, Vd"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.ForeColor = System.Drawing.Color.Blue
        Me.Label34.Location = New System.Drawing.Point(352, 32)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(31, 13)
        Me.Label34.TabIndex = 343
        Me.Label34.Text = "Iq, Id"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.ForeColor = System.Drawing.Color.Green
        Me.Label23.Location = New System.Drawing.Point(352, 64)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(33, 13)
        Me.Label23.TabIndex = 342
        Me.Label23.Text = "alpha"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.ForeColor = System.Drawing.Color.Red
        Me.Label22.Location = New System.Drawing.Point(352, 16)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(66, 13)
        Me.Label22.TabIndex = 341
        Me.Label22.Text = "Ialpha, Ibeta"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.ProgressControl4)
        Me.GroupBox4.Controls.Add(Me.ProgressControl3)
        Me.GroupBox4.Controls.Add(Me.ProgressControl2)
        Me.GroupBox4.Controls.Add(Me.ProgressControl1)
        Me.GroupBox4.Controls.Add(Me.Label40)
        Me.GroupBox4.Controls.Add(Me.Label39)
        Me.GroupBox4.Controls.Add(Me.Label38)
        Me.GroupBox4.Controls.Add(Me.Label37)
        Me.GroupBox4.Location = New System.Drawing.Point(7, 430)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(349, 191)
        Me.GroupBox4.TabIndex = 342
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Feedback"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(5, 144)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(29, 13)
        Me.Label40.TabIndex = 323
        Me.Label40.Text = "D int"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(5, 105)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(29, 13)
        Me.Label39.TabIndex = 322
        Me.Label39.Text = "Q int"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(5, 66)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(39, 13)
        Me.Label38.TabIndex = 321
        Me.Label38.Text = "D error"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(5, 27)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(39, 13)
        Me.Label37.TabIndex = 320
        Me.Label37.Text = "Q error"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.TrackBarQKi)
        Me.GroupBox3.Controls.Add(Me.TrackBarQ_SP)
        Me.GroupBox3.Controls.Add(Me.TrackBarQKp)
        Me.GroupBox3.Controls.Add(Me.Label14)
        Me.GroupBox3.Controls.Add(Me.Label17)
        Me.GroupBox3.Controls.Add(Me.RadioButtonManualSpeed)
        Me.GroupBox3.Controls.Add(Me.LabelQKp)
        Me.GroupBox3.Controls.Add(Me.RadioButtonAutoSpeed)
        Me.GroupBox3.Controls.Add(Me.Label7)
        Me.GroupBox3.Controls.Add(Me.LabelQ_SP)
        Me.GroupBox3.Controls.Add(Me.Label15)
        Me.GroupBox3.Controls.Add(Me.LabelQKi)
        Me.GroupBox3.Location = New System.Drawing.Point(6, 3)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(350, 241)
        Me.GroupBox3.TabIndex = 341
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Q"
        '
        'TrackBarQKi
        '
        Me.TrackBarQKi.Location = New System.Drawing.Point(30, 190)
        Me.TrackBarQKi.Maximum = 1000
        Me.TrackBarQKi.Name = "TrackBarQKi"
        Me.TrackBarQKi.Size = New System.Drawing.Size(257, 45)
        Me.TrackBarQKi.TabIndex = 347
        Me.TrackBarQKi.TickFrequency = 32
        '
        'TrackBarQ_SP
        '
        Me.TrackBarQ_SP.Location = New System.Drawing.Point(30, 88)
        Me.TrackBarQ_SP.Maximum = 320
        Me.TrackBarQ_SP.Minimum = -320
        Me.TrackBarQ_SP.Name = "TrackBarQ_SP"
        Me.TrackBarQ_SP.Size = New System.Drawing.Size(257, 45)
        Me.TrackBarQ_SP.TabIndex = 345
        Me.TrackBarQ_SP.TickFrequency = 10
        '
        'TrackBarQKp
        '
        Me.TrackBarQKp.Location = New System.Drawing.Point(30, 139)
        Me.TrackBarQKp.Maximum = 1000
        Me.TrackBarQKp.Name = "TrackBarQKp"
        Me.TrackBarQKp.Size = New System.Drawing.Size(257, 45)
        Me.TrackBarQKp.TabIndex = 346
        Me.TrackBarQKp.TickFrequency = 32
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(14, 142)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(20, 13)
        Me.Label14.TabIndex = 291
        Me.Label14.Text = "Kp"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(15, 19)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(59, 13)
        Me.Label17.TabIndex = 335
        Me.Label17.Text = "Speed PID"
        '
        'RadioButtonManualSpeed
        '
        Me.RadioButtonManualSpeed.AutoSize = True
        Me.RadioButtonManualSpeed.Location = New System.Drawing.Point(18, 58)
        Me.RadioButtonManualSpeed.Name = "RadioButtonManualSpeed"
        Me.RadioButtonManualSpeed.Size = New System.Drawing.Size(202, 17)
        Me.RadioButtonManualSpeed.TabIndex = 334
        Me.RadioButtonManualSpeed.Text = "disabled: manual control of Q setpoint"
        Me.RadioButtonManualSpeed.UseVisualStyleBackColor = True
        '
        'LabelQKp
        '
        Me.LabelQKp.AutoSize = True
        Me.LabelQKp.Location = New System.Drawing.Point(283, 142)
        Me.LabelQKp.Name = "LabelQKp"
        Me.LabelQKp.Size = New System.Drawing.Size(33, 13)
        Me.LabelQKp.TabIndex = 293
        Me.LabelQKp.Text = "value"
        '
        'RadioButtonAutoSpeed
        '
        Me.RadioButtonAutoSpeed.AutoSize = True
        Me.RadioButtonAutoSpeed.Checked = True
        Me.RadioButtonAutoSpeed.Location = New System.Drawing.Point(18, 35)
        Me.RadioButtonAutoSpeed.Name = "RadioButtonAutoSpeed"
        Me.RadioButtonAutoSpeed.Size = New System.Drawing.Size(178, 17)
        Me.RadioButtonAutoSpeed.TabIndex = 333
        Me.RadioButtonAutoSpeed.TabStop = True
        Me.RadioButtonAutoSpeed.Text = "enabled: PID controls Q setpoint"
        Me.RadioButtonAutoSpeed.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(13, 92)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(21, 13)
        Me.Label7.TabIndex = 335
        Me.Label7.Text = "SP"
        '
        'LabelQ_SP
        '
        Me.LabelQ_SP.AutoSize = True
        Me.LabelQ_SP.Location = New System.Drawing.Point(283, 92)
        Me.LabelQ_SP.Name = "LabelQ_SP"
        Me.LabelQ_SP.Size = New System.Drawing.Size(33, 13)
        Me.LabelQ_SP.TabIndex = 334
        Me.LabelQ_SP.Text = "value"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(18, 192)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(16, 13)
        Me.Label15.TabIndex = 292
        Me.Label15.Text = "Ki"
        '
        'LabelQKi
        '
        Me.LabelQKi.AutoSize = True
        Me.LabelQKi.Location = New System.Drawing.Point(283, 192)
        Me.LabelQKi.Name = "LabelQKi"
        Me.LabelQKi.Size = New System.Drawing.Size(33, 13)
        Me.LabelQKi.TabIndex = 294
        Me.LabelQKi.Text = "value"
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Controls.Add(Me.TrackBarDKi)
        Me.GroupBox2.Controls.Add(Me.TrackBarD_SP)
        Me.GroupBox2.Controls.Add(Me.TrackBarDKp)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.LabelD_SP)
        Me.GroupBox2.Controls.Add(Me.Label33)
        Me.GroupBox2.Controls.Add(Me.Label18)
        Me.GroupBox2.Controls.Add(Me.LabelDKp)
        Me.GroupBox2.Controls.Add(Me.LabelDKi)
        Me.GroupBox2.Location = New System.Drawing.Point(6, 250)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(350, 174)
        Me.GroupBox2.TabIndex = 340
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "D"
        '
        'TrackBarDKi
        '
        Me.TrackBarDKi.Location = New System.Drawing.Point(30, 121)
        Me.TrackBarDKi.Maximum = 1000
        Me.TrackBarDKi.Name = "TrackBarDKi"
        Me.TrackBarDKi.Size = New System.Drawing.Size(257, 45)
        Me.TrackBarDKi.TabIndex = 344
        Me.TrackBarDKi.TickFrequency = 32
        '
        'TrackBarD_SP
        '
        Me.TrackBarD_SP.Location = New System.Drawing.Point(30, 19)
        Me.TrackBarD_SP.Maximum = 320
        Me.TrackBarD_SP.Minimum = -320
        Me.TrackBarD_SP.Name = "TrackBarD_SP"
        Me.TrackBarD_SP.Size = New System.Drawing.Size(257, 45)
        Me.TrackBarD_SP.TabIndex = 342
        Me.TrackBarD_SP.TickFrequency = 10
        '
        'TrackBarDKp
        '
        Me.TrackBarDKp.Location = New System.Drawing.Point(30, 70)
        Me.TrackBarDKp.Maximum = 1000
        Me.TrackBarDKp.Name = "TrackBarDKp"
        Me.TrackBarDKp.Size = New System.Drawing.Size(257, 45)
        Me.TrackBarDKp.TabIndex = 343
        Me.TrackBarDKp.TickFrequency = 32
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(13, 23)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(21, 13)
        Me.Label2.TabIndex = 338
        Me.Label2.Text = "SP"
        '
        'LabelD_SP
        '
        Me.LabelD_SP.AutoSize = True
        Me.LabelD_SP.Location = New System.Drawing.Point(283, 23)
        Me.LabelD_SP.Name = "LabelD_SP"
        Me.LabelD_SP.Size = New System.Drawing.Size(33, 13)
        Me.LabelD_SP.TabIndex = 337
        Me.LabelD_SP.Text = "value"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(10, 74)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(20, 13)
        Me.Label33.TabIndex = 298
        Me.Label33.Text = "Kp"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(11, 123)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(16, 13)
        Me.Label18.TabIndex = 299
        Me.Label18.Text = "Ki"
        '
        'LabelDKp
        '
        Me.LabelDKp.AutoSize = True
        Me.LabelDKp.Location = New System.Drawing.Point(284, 73)
        Me.LabelDKp.Name = "LabelDKp"
        Me.LabelDKp.Size = New System.Drawing.Size(33, 13)
        Me.LabelDKp.TabIndex = 300
        Me.LabelDKp.Text = "value"
        '
        'LabelDKi
        '
        Me.LabelDKi.AutoSize = True
        Me.LabelDKi.Location = New System.Drawing.Point(283, 124)
        Me.LabelDKi.Name = "LabelDKi"
        Me.LabelDKi.Size = New System.Drawing.Size(33, 13)
        Me.LabelDKi.TabIndex = 301
        Me.LabelDKi.Text = "value"
        '
        'TabSpeedPID
        '
        Me.TabSpeedPID.Controls.Add(Me.GroupBox10)
        Me.TabSpeedPID.Controls.Add(Me.GroupBox9)
        Me.TabSpeedPID.Location = New System.Drawing.Point(4, 22)
        Me.TabSpeedPID.Name = "TabSpeedPID"
        Me.TabSpeedPID.Padding = New System.Windows.Forms.Padding(3)
        Me.TabSpeedPID.Size = New System.Drawing.Size(790, 627)
        Me.TabSpeedPID.TabIndex = 2
        Me.TabSpeedPID.Text = "Speed PID controller"
        Me.TabSpeedPID.UseVisualStyleBackColor = True
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.ProgressControlSpeedErr)
        Me.GroupBox10.Controls.Add(Me.Label13)
        Me.GroupBox10.Controls.Add(Me.ProgressControlSpeedDer)
        Me.GroupBox10.Controls.Add(Me.Label12)
        Me.GroupBox10.Controls.Add(Me.ProgressControlSpeedInt)
        Me.GroupBox10.Controls.Add(Me.Label11)
        Me.GroupBox10.Location = New System.Drawing.Point(7, 230)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(437, 163)
        Me.GroupBox10.TabIndex = 351
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "Feedback"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(33, 31)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(54, 13)
        Me.Label13.TabIndex = 274
        Me.Label13.Text = "speed err "
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(33, 70)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(50, 13)
        Me.Label12.TabIndex = 275
        Me.Label12.Text = "speed int"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(33, 109)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(54, 13)
        Me.Label11.TabIndex = 276
        Me.Label11.Text = "speed der"
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.TrackBarSpeedSP)
        Me.GroupBox9.Controls.Add(Me.TrackBarSpeedKd)
        Me.GroupBox9.Controls.Add(Me.ValueLabelSpeedSP)
        Me.GroupBox9.Controls.Add(Me.TrackBarSpeedKi)
        Me.GroupBox9.Controls.Add(Me.Label28)
        Me.GroupBox9.Controls.Add(Me.TrackBarSpeedKp)
        Me.GroupBox9.Controls.Add(Me.Label27)
        Me.GroupBox9.Controls.Add(Me.LabelSpeedKp)
        Me.GroupBox9.Controls.Add(Me.Label19)
        Me.GroupBox9.Controls.Add(Me.LabelSpeedKi)
        Me.GroupBox9.Controls.Add(Me.Label24)
        Me.GroupBox9.Controls.Add(Me.LabelSpeedKd)
        Me.GroupBox9.Controls.Add(Me.Label1)
        Me.GroupBox9.Location = New System.Drawing.Point(6, 6)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(438, 217)
        Me.GroupBox9.TabIndex = 350
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "PID settings"
        '
        'TrackBarSpeedSP
        '
        Me.TrackBarSpeedSP.Location = New System.Drawing.Point(89, 19)
        Me.TrackBarSpeedSP.Maximum = 3200
        Me.TrackBarSpeedSP.Name = "TrackBarSpeedSP"
        Me.TrackBarSpeedSP.Size = New System.Drawing.Size(257, 45)
        Me.TrackBarSpeedSP.TabIndex = 346
        Me.TrackBarSpeedSP.TickFrequency = 100
        '
        'TrackBarSpeedKd
        '
        Me.TrackBarSpeedKd.Location = New System.Drawing.Point(89, 172)
        Me.TrackBarSpeedKd.Maximum = 3200
        Me.TrackBarSpeedKd.Name = "TrackBarSpeedKd"
        Me.TrackBarSpeedKd.Size = New System.Drawing.Size(257, 45)
        Me.TrackBarSpeedKd.TabIndex = 349
        Me.TrackBarSpeedKd.TickFrequency = 100
        '
        'ValueLabelSpeedSP
        '
        Me.ValueLabelSpeedSP.AutoSize = True
        Me.ValueLabelSpeedSP.Location = New System.Drawing.Point(348, 19)
        Me.ValueLabelSpeedSP.Name = "ValueLabelSpeedSP"
        Me.ValueLabelSpeedSP.Size = New System.Drawing.Size(33, 13)
        Me.ValueLabelSpeedSP.TabIndex = 252
        Me.ValueLabelSpeedSP.Text = "value"
        '
        'TrackBarSpeedKi
        '
        Me.TrackBarSpeedKi.Location = New System.Drawing.Point(89, 121)
        Me.TrackBarSpeedKi.Maximum = 3200
        Me.TrackBarSpeedKi.Name = "TrackBarSpeedKi"
        Me.TrackBarSpeedKi.Size = New System.Drawing.Size(257, 45)
        Me.TrackBarSpeedKi.TabIndex = 348
        Me.TrackBarSpeedKi.TickFrequency = 100
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(31, 70)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(52, 13)
        Me.Label28.TabIndex = 256
        Me.Label28.Text = "speed Kp"
        '
        'TrackBarSpeedKp
        '
        Me.TrackBarSpeedKp.Location = New System.Drawing.Point(89, 70)
        Me.TrackBarSpeedKp.Maximum = 3200
        Me.TrackBarSpeedKp.Name = "TrackBarSpeedKp"
        Me.TrackBarSpeedKp.Size = New System.Drawing.Size(257, 45)
        Me.TrackBarSpeedKp.TabIndex = 347
        Me.TrackBarSpeedKp.TickFrequency = 100
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(35, 121)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(48, 13)
        Me.Label27.TabIndex = 257
        Me.Label27.Text = "speed Ki"
        '
        'LabelSpeedKp
        '
        Me.LabelSpeedKp.AutoSize = True
        Me.LabelSpeedKp.Location = New System.Drawing.Point(348, 70)
        Me.LabelSpeedKp.Name = "LabelSpeedKp"
        Me.LabelSpeedKp.Size = New System.Drawing.Size(33, 13)
        Me.LabelSpeedKp.TabIndex = 258
        Me.LabelSpeedKp.Text = "value"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(7, 32)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(37, 13)
        Me.Label19.TabIndex = 323
        Me.Label19.Text = "[RPM]"
        '
        'LabelSpeedKi
        '
        Me.LabelSpeedKi.AutoSize = True
        Me.LabelSpeedKi.Location = New System.Drawing.Point(348, 121)
        Me.LabelSpeedKi.Name = "LabelSpeedKi"
        Me.LabelSpeedKi.Size = New System.Drawing.Size(33, 13)
        Me.LabelSpeedKi.TabIndex = 259
        Me.LabelSpeedKi.Text = "value"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(31, 172)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(52, 13)
        Me.Label24.TabIndex = 262
        Me.Label24.Text = "speed Kd"
        '
        'LabelSpeedKd
        '
        Me.LabelSpeedKd.AutoSize = True
        Me.LabelSpeedKd.Location = New System.Drawing.Point(348, 172)
        Me.LabelSpeedKd.Name = "LabelSpeedKd"
        Me.LabelSpeedKd.Size = New System.Drawing.Size(33, 13)
        Me.LabelSpeedKd.TabIndex = 264
        Me.LabelSpeedKd.Text = "value"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(7, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(76, 13)
        Me.Label1.TabIndex = 278
        Me.Label1.Text = "speed setpoint"
        '
        'TabVectorConrol
        '
        Me.TabVectorConrol.Controls.Add(Me.GroupBox8)
        Me.TabVectorConrol.Controls.Add(Me.GroupBox7)
        Me.TabVectorConrol.Controls.Add(Me.GroupBox6)
        Me.TabVectorConrol.Location = New System.Drawing.Point(4, 22)
        Me.TabVectorConrol.Name = "TabVectorConrol"
        Me.TabVectorConrol.Padding = New System.Windows.Forms.Padding(3)
        Me.TabVectorConrol.Size = New System.Drawing.Size(790, 627)
        Me.TabVectorConrol.TabIndex = 1
        Me.TabVectorConrol.Text = "SVPWM model"
        Me.TabVectorConrol.UseVisualStyleBackColor = True
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.SVPWMControl1)
        Me.GroupBox8.Controls.Add(Me.CheckBoxSync)
        Me.GroupBox8.Controls.Add(Me.CheckBoxAutoRotate)
        Me.GroupBox8.Controls.Add(Me.CheckBoxTransmit)
        Me.GroupBox8.Location = New System.Drawing.Point(9, 6)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(313, 402)
        Me.GroupBox8.TabIndex = 242
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "SVPWM model"
        '
        'CheckBoxSync
        '
        Me.CheckBoxSync.AutoSize = True
        Me.CheckBoxSync.Checked = True
        Me.CheckBoxSync.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBoxSync.Location = New System.Drawing.Point(6, 331)
        Me.CheckBoxSync.Name = "CheckBoxSync"
        Me.CheckBoxSync.Size = New System.Drawing.Size(159, 17)
        Me.CheckBoxSync.TabIndex = 230
        Me.CheckBoxSync.Text = "Sync model with demoboard"
        Me.CheckBoxSync.UseVisualStyleBackColor = True
        '
        'CheckBoxAutoRotate
        '
        Me.CheckBoxAutoRotate.AutoSize = True
        Me.CheckBoxAutoRotate.Enabled = False
        Me.CheckBoxAutoRotate.Location = New System.Drawing.Point(6, 354)
        Me.CheckBoxAutoRotate.Name = "CheckBoxAutoRotate"
        Me.CheckBoxAutoRotate.Size = New System.Drawing.Size(78, 17)
        Me.CheckBoxAutoRotate.TabIndex = 228
        Me.CheckBoxAutoRotate.Text = "Auto rotate"
        Me.CheckBoxAutoRotate.UseVisualStyleBackColor = True
        '
        'CheckBoxTransmit
        '
        Me.CheckBoxTransmit.AutoSize = True
        Me.CheckBoxTransmit.Enabled = False
        Me.CheckBoxTransmit.Location = New System.Drawing.Point(6, 377)
        Me.CheckBoxTransmit.Name = "CheckBoxTransmit"
        Me.CheckBoxTransmit.Size = New System.Drawing.Size(173, 17)
        Me.CheckBoxTransmit.TabIndex = 239
        Me.CheckBoxTransmit.Text = "Transmit model values to board"
        Me.CheckBoxTransmit.UseVisualStyleBackColor = True
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.PWM1_actual)
        Me.GroupBox7.Controls.Add(Me.PWM2_actual)
        Me.GroupBox7.Controls.Add(Me.PWM3_actual)
        Me.GroupBox7.Controls.Add(Me.Label10)
        Me.GroupBox7.Controls.Add(Me.Label8)
        Me.GroupBox7.Controls.Add(Me.Label9)
        Me.GroupBox7.Location = New System.Drawing.Point(559, 6)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(225, 166)
        Me.GroupBox7.TabIndex = 241
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "PWM signals from demoboard"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(10, 19)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(17, 13)
        Me.Label10.TabIndex = 234
        Me.Label10.Text = "A:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(10, 109)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(17, 13)
        Me.Label8.TabIndex = 236
        Me.Label8.Text = "C:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(10, 64)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(17, 13)
        Me.Label9.TabIndex = 235
        Me.Label9.Text = "B:"
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.PWM3_virtual)
        Me.GroupBox6.Controls.Add(Me.PWM1_virtual)
        Me.GroupBox6.Controls.Add(Me.PWM2_virtual)
        Me.GroupBox6.Controls.Add(Me.LabelA)
        Me.GroupBox6.Controls.Add(Me.LabelB)
        Me.GroupBox6.Controls.Add(Me.LabelC)
        Me.GroupBox6.Location = New System.Drawing.Point(328, 6)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(225, 166)
        Me.GroupBox6.TabIndex = 240
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "PWM signals from model"
        '
        'LabelA
        '
        Me.LabelA.AutoSize = True
        Me.LabelA.Location = New System.Drawing.Point(12, 19)
        Me.LabelA.Name = "LabelA"
        Me.LabelA.Size = New System.Drawing.Size(17, 13)
        Me.LabelA.TabIndex = 225
        Me.LabelA.Text = "A:"
        '
        'LabelB
        '
        Me.LabelB.AutoSize = True
        Me.LabelB.Location = New System.Drawing.Point(12, 64)
        Me.LabelB.Name = "LabelB"
        Me.LabelB.Size = New System.Drawing.Size(17, 13)
        Me.LabelB.TabIndex = 226
        Me.LabelB.Text = "B:"
        '
        'LabelC
        '
        Me.LabelC.AutoSize = True
        Me.LabelC.Location = New System.Drawing.Point(12, 109)
        Me.LabelC.Name = "LabelC"
        Me.LabelC.Size = New System.Drawing.Size(17, 13)
        Me.LabelC.TabIndex = 227
        Me.LabelC.Text = "C:"
        '
        'TabParameters
        '
        Me.TabParameters.Controls.Add(Me.Label42)
        Me.TabParameters.Controls.Add(Me.Label36)
        Me.TabParameters.Controls.Add(Me.Label43)
        Me.TabParameters.Controls.Add(Me.Label6)
        Me.TabParameters.Controls.Add(Me.ButtonDivL)
        Me.TabParameters.Controls.Add(Me.ButtonDivR)
        Me.TabParameters.Controls.Add(Me.TextBox1)
        Me.TabParameters.Controls.Add(Me.LabelTest3)
        Me.TabParameters.Controls.Add(Me.TrackBarTest3)
        Me.TabParameters.Controls.Add(Me.LabelTest4)
        Me.TabParameters.Controls.Add(Me.TrackBarTest4)
        Me.TabParameters.Controls.Add(Me.LabelTest1)
        Me.TabParameters.Controls.Add(Me.TrackBarTest1)
        Me.TabParameters.Controls.Add(Me.LabelTest2)
        Me.TabParameters.Controls.Add(Me.TrackBarTest2)
        Me.TabParameters.Controls.Add(Me.LabelPeriodTime)
        Me.TabParameters.Controls.Add(Me.Label32)
        Me.TabParameters.Controls.Add(Me.Label31)
        Me.TabParameters.Controls.Add(Me.Label30)
        Me.TabParameters.Controls.Add(Me.Label29)
        Me.TabParameters.Controls.Add(Me.Label26)
        Me.TabParameters.Controls.Add(Me.Label25)
        Me.TabParameters.Controls.Add(Me.LabelG)
        Me.TabParameters.Controls.Add(Me.LabelF)
        Me.TabParameters.Controls.Add(Me.PictureBox1)
        Me.TabParameters.Controls.Add(Me.TextBoxOmegaFltrCoef)
        Me.TabParameters.Controls.Add(Me.TextBoxSMCMaxError)
        Me.TabParameters.Controls.Add(Me.TextBoxSMCgain)
        Me.TabParameters.Controls.Add(Me.TextBoxmH)
        Me.TabParameters.Controls.Add(Me.TextBoxmOhm)
        Me.TabParameters.Location = New System.Drawing.Point(4, 22)
        Me.TabParameters.Name = "TabParameters"
        Me.TabParameters.Padding = New System.Windows.Forms.Padding(3)
        Me.TabParameters.Size = New System.Drawing.Size(790, 627)
        Me.TabParameters.TabIndex = 3
        Me.TabParameters.Text = "Virtual motor parameters"
        Me.TabParameters.UseVisualStyleBackColor = True
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(7, 59)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(115, 13)
        Me.Label42.TabIndex = 343
        Me.Label42.Text = "Omega filter coefficient"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(7, 33)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(77, 13)
        Me.Label36.TabIndex = 340
        Me.Label36.Text = "Max SMC error"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(7, 7)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(53, 13)
        Me.Label43.TabIndex = 337
        Me.Label43.Text = "SMC gain"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(558, 7)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(107, 13)
        Me.Label6.TabIndex = 334
        Me.Label6.Text = "Demoboard variables"
        '
        'ButtonDivL
        '
        Me.ButtonDivL.Location = New System.Drawing.Point(217, 110)
        Me.ButtonDivL.Name = "ButtonDivL"
        Me.ButtonDivL.Size = New System.Drawing.Size(26, 22)
        Me.ButtonDivL.TabIndex = 333
        Me.ButtonDivL.Text = "/2"
        Me.ButtonDivL.UseVisualStyleBackColor = True
        '
        'ButtonDivR
        '
        Me.ButtonDivR.Location = New System.Drawing.Point(217, 84)
        Me.ButtonDivR.Name = "ButtonDivR"
        Me.ButtonDivR.Size = New System.Drawing.Size(26, 22)
        Me.ButtonDivR.TabIndex = 331
        Me.ButtonDivR.Text = "/2"
        Me.ButtonDivR.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(560, 23)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(224, 425)
        Me.TextBox1.TabIndex = 330
        '
        'LabelTest3
        '
        Me.LabelTest3.AutoSize = True
        Me.LabelTest3.Location = New System.Drawing.Point(240, 435)
        Me.LabelTest3.Name = "LabelTest3"
        Me.LabelTest3.Size = New System.Drawing.Size(33, 13)
        Me.LabelTest3.TabIndex = 329
        Me.LabelTest3.Text = "value"
        Me.LabelTest3.Visible = False
        '
        'TrackBarTest3
        '
        Me.TrackBarTest3.Location = New System.Drawing.Point(11, 436)
        Me.TrackBarTest3.Maximum = 3200
        Me.TrackBarTest3.Name = "TrackBarTest3"
        Me.TrackBarTest3.Size = New System.Drawing.Size(223, 45)
        Me.TrackBarTest3.TabIndex = 328
        Me.TrackBarTest3.Visible = False
        '
        'LabelTest4
        '
        Me.LabelTest4.AutoSize = True
        Me.LabelTest4.Location = New System.Drawing.Point(240, 483)
        Me.LabelTest4.Name = "LabelTest4"
        Me.LabelTest4.Size = New System.Drawing.Size(33, 13)
        Me.LabelTest4.TabIndex = 327
        Me.LabelTest4.Text = "value"
        Me.LabelTest4.Visible = False
        '
        'TrackBarTest4
        '
        Me.TrackBarTest4.Location = New System.Drawing.Point(11, 483)
        Me.TrackBarTest4.Maximum = 3200
        Me.TrackBarTest4.Name = "TrackBarTest4"
        Me.TrackBarTest4.Size = New System.Drawing.Size(223, 45)
        Me.TrackBarTest4.TabIndex = 326
        Me.TrackBarTest4.Visible = False
        '
        'LabelTest1
        '
        Me.LabelTest1.AutoSize = True
        Me.LabelTest1.Location = New System.Drawing.Point(240, 334)
        Me.LabelTest1.Name = "LabelTest1"
        Me.LabelTest1.Size = New System.Drawing.Size(33, 13)
        Me.LabelTest1.TabIndex = 325
        Me.LabelTest1.Text = "value"
        Me.LabelTest1.Visible = False
        '
        'TrackBarTest1
        '
        Me.TrackBarTest1.Location = New System.Drawing.Point(11, 334)
        Me.TrackBarTest1.Maximum = 3200
        Me.TrackBarTest1.Name = "TrackBarTest1"
        Me.TrackBarTest1.Size = New System.Drawing.Size(223, 45)
        Me.TrackBarTest1.TabIndex = 324
        Me.TrackBarTest1.Visible = False
        '
        'LabelTest2
        '
        Me.LabelTest2.AutoSize = True
        Me.LabelTest2.Location = New System.Drawing.Point(240, 385)
        Me.LabelTest2.Name = "LabelTest2"
        Me.LabelTest2.Size = New System.Drawing.Size(33, 13)
        Me.LabelTest2.TabIndex = 323
        Me.LabelTest2.Text = "value"
        Me.LabelTest2.Visible = False
        '
        'TrackBarTest2
        '
        Me.TrackBarTest2.Location = New System.Drawing.Point(11, 385)
        Me.TrackBarTest2.Maximum = 3200
        Me.TrackBarTest2.Name = "TrackBarTest2"
        Me.TrackBarTest2.Size = New System.Drawing.Size(223, 45)
        Me.TrackBarTest2.TabIndex = 322
        Me.TrackBarTest2.Visible = False
        '
        'LabelPeriodTime
        '
        Me.LabelPeriodTime.AutoSize = True
        Me.LabelPeriodTime.Location = New System.Drawing.Point(8, 140)
        Me.LabelPeriodTime.Name = "LabelPeriodTime"
        Me.LabelPeriodTime.Size = New System.Drawing.Size(126, 13)
        Me.LabelPeriodTime.TabIndex = 302
        Me.LabelPeriodTime.Text = "Control period (T) = 50 us"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(7, 112)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(108, 13)
        Me.Label32.TabIndex = 301
        Me.Label32.Text = "Phase inductance (L)"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(249, 114)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(23, 13)
        Me.Label31.TabIndex = 300
        Me.Label31.Text = "mH"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(249, 88)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(37, 13)
        Me.Label30.TabIndex = 299
        Me.Label30.Text = "mOhm"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(7, 86)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(105, 13)
        Me.Label29.TabIndex = 298
        Me.Label29.Text = "Phase resistance (R)"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.Label26.Location = New System.Drawing.Point(103, 218)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(13, 13)
        Me.Label26.TabIndex = 297
        Me.Label26.Text = "="
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.Label25.Location = New System.Drawing.Point(103, 177)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(13, 13)
        Me.Label25.TabIndex = 296
        Me.Label25.Text = "="
        '
        'LabelG
        '
        Me.LabelG.AutoSize = True
        Me.LabelG.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.LabelG.Location = New System.Drawing.Point(122, 218)
        Me.LabelG.Name = "LabelG"
        Me.LabelG.Size = New System.Drawing.Size(27, 13)
        Me.LabelG.TabIndex = 295
        Me.LabelG.Text = "<G>"
        '
        'LabelF
        '
        Me.LabelF.AutoSize = True
        Me.LabelF.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.LabelF.Location = New System.Drawing.Point(122, 177)
        Me.LabelF.Name = "LabelF"
        Me.LabelF.Size = New System.Drawing.Size(25, 13)
        Me.LabelF.TabIndex = 294
        Me.LabelF.Text = "<F>"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(281, 19)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(34, 13)
        Me.Label5.TabIndex = 278
        Me.Label5.Text = "RPM:"
        '
        'LabelRPM
        '
        Me.LabelRPM.AutoSize = True
        Me.LabelRPM.Location = New System.Drawing.Point(313, 18)
        Me.LabelRPM.Name = "LabelRPM"
        Me.LabelRPM.Size = New System.Drawing.Size(33, 13)
        Me.LabelRPM.TabIndex = 277
        Me.LabelRPM.Text = "value"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label20)
        Me.GroupBox1.Controls.Add(Me.RadioButtonSensorless)
        Me.GroupBox1.Controls.Add(Me.RadioButtonQEI)
        Me.GroupBox1.Controls.Add(Me.LabelPower)
        Me.GroupBox1.Controls.Add(Me.Label21)
        Me.GroupBox1.Controls.Add(Me.LabelMode)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.LabelRPM)
        Me.GroupBox1.Controls.Add(Me.Label16)
        Me.GroupBox1.Controls.Add(Me.LabelTemp)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 27)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(669, 42)
        Me.GroupBox1.TabIndex = 73
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Common"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(486, 18)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(37, 13)
        Me.Label20.TabIndex = 281
        Me.Label20.Text = "Mode:"
        '
        'RadioButtonSensorless
        '
        Me.RadioButtonSensorless.AutoSize = True
        Me.RadioButtonSensorless.Location = New System.Drawing.Point(55, 16)
        Me.RadioButtonSensorless.Name = "RadioButtonSensorless"
        Me.RadioButtonSensorless.Size = New System.Drawing.Size(76, 17)
        Me.RadioButtonSensorless.TabIndex = 287
        Me.RadioButtonSensorless.Text = "Sensorless"
        Me.RadioButtonSensorless.UseVisualStyleBackColor = True
        '
        'RadioButtonQEI
        '
        Me.RadioButtonQEI.AutoSize = True
        Me.RadioButtonQEI.Checked = True
        Me.RadioButtonQEI.Location = New System.Drawing.Point(6, 16)
        Me.RadioButtonQEI.Name = "RadioButtonQEI"
        Me.RadioButtonQEI.Size = New System.Drawing.Size(43, 17)
        Me.RadioButtonQEI.TabIndex = 286
        Me.RadioButtonQEI.TabStop = True
        Me.RadioButtonQEI.Text = "QEI"
        Me.RadioButtonQEI.UseVisualStyleBackColor = True
        '
        'LabelPower
        '
        Me.LabelPower.AutoSize = True
        Me.LabelPower.Location = New System.Drawing.Point(415, 18)
        Me.LabelPower.Name = "LabelPower"
        Me.LabelPower.Size = New System.Drawing.Size(33, 13)
        Me.LabelPower.TabIndex = 281
        Me.LabelPower.Text = "value"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(376, 18)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(40, 13)
        Me.Label21.TabIndex = 280
        Me.Label21.Text = "Power:"
        '
        'LabelMode
        '
        Me.LabelMode.AutoSize = True
        Me.LabelMode.Location = New System.Drawing.Point(521, 18)
        Me.LabelMode.Name = "LabelMode"
        Me.LabelMode.Size = New System.Drawing.Size(33, 13)
        Me.LabelMode.TabIndex = 279
        Me.LabelMode.Text = "value"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(159, 18)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(70, 13)
        Me.Label16.TabIndex = 68
        Me.Label16.Text = "Temperature:"
        '
        'LabelTemp
        '
        Me.LabelTemp.AutoSize = True
        Me.LabelTemp.Location = New System.Drawing.Point(226, 18)
        Me.LabelTemp.Name = "LabelTemp"
        Me.LabelTemp.Size = New System.Drawing.Size(33, 13)
        Me.LabelTemp.TabIndex = 67
        Me.LabelTemp.Text = "value"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.EditToolStripMenuItem, Me.ToolsToolStripMenuItem, Me.AboutToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(821, 24)
        Me.MenuStrip1.TabIndex = 74
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MenuItemOpen, Me.MenuItemSave, Me.ToolStripSeparator1, Me.MenuItemExit})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(35, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(128, 6)
        '
        'MenuItemExit
        '
        Me.MenuItemExit.Name = "MenuItemExit"
        Me.MenuItemExit.Size = New System.Drawing.Size(131, 22)
        Me.MenuItemExit.Text = "Exit"
        '
        'EditToolStripMenuItem
        '
        Me.EditToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MenuItemSettings})
        Me.EditToolStripMenuItem.Name = "EditToolStripMenuItem"
        Me.EditToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.EditToolStripMenuItem.Text = "Edit"
        '
        'ToolsToolStripMenuItem
        '
        Me.ToolsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddScopeToolStripMenuItem, Me.DataloggerToolStripMenuItem, Me.FixedPointToolToolStripMenuItem})
        Me.ToolsToolStripMenuItem.Name = "ToolsToolStripMenuItem"
        Me.ToolsToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.ToolsToolStripMenuItem.Text = "Tools"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(48, 20)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'ButtonCOM
        '
        Me.ButtonCOM.BackgroundImage = Global.FOCinterface.My.Resources.Resources.Serial
        Me.ButtonCOM.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ButtonCOM.Location = New System.Drawing.Point(687, 32)
        Me.ButtonCOM.Name = "ButtonCOM"
        Me.ButtonCOM.Size = New System.Drawing.Size(38, 38)
        Me.ButtonCOM.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.ButtonCOM, "Open/close the serial port. Configure port under Edit->COM settings")
        Me.ButtonCOM.UseVisualStyleBackColor = True
        '
        'ButtonLog
        '
        Me.ButtonLog.BackgroundImage = Global.FOCinterface.My.Resources.Resources.Log
        Me.ButtonLog.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ButtonLog.Location = New System.Drawing.Point(771, 32)
        Me.ButtonLog.Name = "ButtonLog"
        Me.ButtonLog.Size = New System.Drawing.Size(38, 38)
        Me.ButtonLog.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.ButtonLog, "Open the datalogger window")
        Me.ButtonLog.UseVisualStyleBackColor = True
        '
        'ButtonScope
        '
        Me.ButtonScope.BackgroundImage = Global.FOCinterface.My.Resources.Resources.Scope
        Me.ButtonScope.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.ButtonScope.Location = New System.Drawing.Point(729, 32)
        Me.ButtonScope.Name = "ButtonScope"
        Me.ButtonScope.Size = New System.Drawing.Size(38, 38)
        Me.ButtonScope.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.ButtonScope, "Open a new scope window")
        Me.ButtonScope.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.FOCinterface.My.Resources.Resources.FGFormula
        Me.PictureBox1.Location = New System.Drawing.Point(11, 165)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(86, 77)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'MenuItemOpen
        '
        Me.MenuItemOpen.Image = Global.FOCinterface.My.Resources.Resources.OpenFile
        Me.MenuItemOpen.Name = "MenuItemOpen"
        Me.MenuItemOpen.Size = New System.Drawing.Size(131, 22)
        Me.MenuItemOpen.Text = "Open motor"
        '
        'MenuItemSave
        '
        Me.MenuItemSave.Image = Global.FOCinterface.My.Resources.Resources.SaveCurrentFile
        Me.MenuItemSave.Name = "MenuItemSave"
        Me.MenuItemSave.Size = New System.Drawing.Size(131, 22)
        Me.MenuItemSave.Text = "Save motor"
        '
        'MenuItemSettings
        '
        Me.MenuItemSettings.Image = Global.FOCinterface.My.Resources.Resources.Serial
        Me.MenuItemSettings.Name = "MenuItemSettings"
        Me.MenuItemSettings.Size = New System.Drawing.Size(138, 22)
        Me.MenuItemSettings.Text = "COM settings"
        '
        'AddScopeToolStripMenuItem
        '
        Me.AddScopeToolStripMenuItem.Image = Global.FOCinterface.My.Resources.Resources.Scope
        Me.AddScopeToolStripMenuItem.Name = "AddScopeToolStripMenuItem"
        Me.AddScopeToolStripMenuItem.Size = New System.Drawing.Size(150, 22)
        Me.AddScopeToolStripMenuItem.Text = "Add scope"
        '
        'DataloggerToolStripMenuItem
        '
        Me.DataloggerToolStripMenuItem.Image = Global.FOCinterface.My.Resources.Resources.Log
        Me.DataloggerToolStripMenuItem.Name = "DataloggerToolStripMenuItem"
        Me.DataloggerToolStripMenuItem.Size = New System.Drawing.Size(150, 22)
        Me.DataloggerToolStripMenuItem.Text = "Datalogger"
        '
        'FixedPointToolToolStripMenuItem
        '
        Me.FixedPointToolToolStripMenuItem.Image = Global.FOCinterface.My.Resources.Resources.Code
        Me.FixedPointToolToolStripMenuItem.Name = "FixedPointToolToolStripMenuItem"
        Me.FixedPointToolToolStripMenuItem.Size = New System.Drawing.Size(150, 22)
        Me.FixedPointToolToolStripMenuItem.Text = "Fixed Point Tool"
        '
        'VectorViewer1
        '
        Me.VectorViewer1.BackColor = System.Drawing.Color.Transparent
        Me.VectorViewer1.Location = New System.Drawing.Point(12, 14)
        Me.VectorViewer1.Name = "VectorViewer1"
        Me.VectorViewer1.Size = New System.Drawing.Size(400, 400)
        Me.VectorViewer1.TabIndex = 340
        Me.VectorViewer1.Xmax = 5.0!
        Me.VectorViewer1.Xmin = -5.0!
        Me.VectorViewer1.Ymax = 5.0!
        Me.VectorViewer1.Ymin = -5.0!
        '
        'ProgressControl4
        '
        Me.ProgressControl4.BackColor = System.Drawing.Color.Black
        Me.ProgressControl4.Location = New System.Drawing.Point(47, 144)
        Me.ProgressControl4.Max = 1024.0!
        Me.ProgressControl4.Min = -1024.0!
        Me.ProgressControl4.Name = "ProgressControl4"
        Me.ProgressControl4.ShowMinMax = False
        Me.ProgressControl4.Size = New System.Drawing.Size(257, 33)
        Me.ProgressControl4.TabIndex = 327
        Me.ProgressControl4.Text = "ProgressControl4"
        Me.ProgressControl4.Value = 0.0!
        Me.ProgressControl4.Visualisation = FOCinterface.ProgressControl.VisualType.Line
        '
        'ProgressControl3
        '
        Me.ProgressControl3.BackColor = System.Drawing.Color.Black
        Me.ProgressControl3.Location = New System.Drawing.Point(47, 105)
        Me.ProgressControl3.Max = 1024.0!
        Me.ProgressControl3.Min = -1024.0!
        Me.ProgressControl3.Name = "ProgressControl3"
        Me.ProgressControl3.ShowMinMax = False
        Me.ProgressControl3.Size = New System.Drawing.Size(257, 33)
        Me.ProgressControl3.TabIndex = 326
        Me.ProgressControl3.Text = "ProgressControl3"
        Me.ProgressControl3.Value = 0.0!
        Me.ProgressControl3.Visualisation = FOCinterface.ProgressControl.VisualType.Line
        '
        'ProgressControl2
        '
        Me.ProgressControl2.BackColor = System.Drawing.Color.Black
        Me.ProgressControl2.Location = New System.Drawing.Point(47, 66)
        Me.ProgressControl2.Max = 32.0!
        Me.ProgressControl2.Min = -32.0!
        Me.ProgressControl2.Name = "ProgressControl2"
        Me.ProgressControl2.ShowMinMax = False
        Me.ProgressControl2.Size = New System.Drawing.Size(257, 33)
        Me.ProgressControl2.TabIndex = 325
        Me.ProgressControl2.Text = "ProgressControl2"
        Me.ProgressControl2.Value = 0.0!
        Me.ProgressControl2.Visualisation = FOCinterface.ProgressControl.VisualType.Line
        '
        'ProgressControl1
        '
        Me.ProgressControl1.BackColor = System.Drawing.Color.Black
        Me.ProgressControl1.Location = New System.Drawing.Point(47, 27)
        Me.ProgressControl1.Max = 32.0!
        Me.ProgressControl1.Min = -32.0!
        Me.ProgressControl1.Name = "ProgressControl1"
        Me.ProgressControl1.ShowMinMax = False
        Me.ProgressControl1.Size = New System.Drawing.Size(257, 33)
        Me.ProgressControl1.TabIndex = 324
        Me.ProgressControl1.Text = "ProgressControl1"
        Me.ProgressControl1.UseWaitCursor = True
        Me.ProgressControl1.Value = 0.0!
        Me.ProgressControl1.Visualisation = FOCinterface.ProgressControl.VisualType.Line
        '
        'ProgressControlSpeedErr
        '
        Me.ProgressControlSpeedErr.BackColor = System.Drawing.Color.Black
        Me.ProgressControlSpeedErr.Location = New System.Drawing.Point(88, 31)
        Me.ProgressControlSpeedErr.Max = 32.0!
        Me.ProgressControlSpeedErr.Min = -32.0!
        Me.ProgressControlSpeedErr.Name = "ProgressControlSpeedErr"
        Me.ProgressControlSpeedErr.ShowMinMax = True
        Me.ProgressControlSpeedErr.Size = New System.Drawing.Size(253, 33)
        Me.ProgressControlSpeedErr.TabIndex = 317
        Me.ProgressControlSpeedErr.Value = 0.0!
        Me.ProgressControlSpeedErr.Visualisation = FOCinterface.ProgressControl.VisualType.Line
        '
        'ProgressControlSpeedDer
        '
        Me.ProgressControlSpeedDer.BackColor = System.Drawing.Color.Black
        Me.ProgressControlSpeedDer.Location = New System.Drawing.Point(88, 109)
        Me.ProgressControlSpeedDer.Max = 32.0!
        Me.ProgressControlSpeedDer.Min = -32.0!
        Me.ProgressControlSpeedDer.Name = "ProgressControlSpeedDer"
        Me.ProgressControlSpeedDer.ShowMinMax = True
        Me.ProgressControlSpeedDer.Size = New System.Drawing.Size(253, 33)
        Me.ProgressControlSpeedDer.TabIndex = 319
        Me.ProgressControlSpeedDer.Text = "ProgressControlSpeedDer"
        Me.ProgressControlSpeedDer.Value = 0.0!
        Me.ProgressControlSpeedDer.Visualisation = FOCinterface.ProgressControl.VisualType.Line
        '
        'ProgressControlSpeedInt
        '
        Me.ProgressControlSpeedInt.BackColor = System.Drawing.Color.Black
        Me.ProgressControlSpeedInt.Location = New System.Drawing.Point(88, 70)
        Me.ProgressControlSpeedInt.Max = 1024.0!
        Me.ProgressControlSpeedInt.Min = -1024.0!
        Me.ProgressControlSpeedInt.Name = "ProgressControlSpeedInt"
        Me.ProgressControlSpeedInt.ShowMinMax = True
        Me.ProgressControlSpeedInt.Size = New System.Drawing.Size(253, 33)
        Me.ProgressControlSpeedInt.TabIndex = 318
        Me.ProgressControlSpeedInt.Text = "ProgressControlSpeedInt"
        Me.ProgressControlSpeedInt.Value = 0.0!
        Me.ProgressControlSpeedInt.Visualisation = FOCinterface.ProgressControl.VisualType.Line
        '
        'SVPWMControl1
        '
        Me.SVPWMControl1.Alpha = 20
        Me.SVPWMControl1.BackColor = System.Drawing.Color.White
        Me.SVPWMControl1.Location = New System.Drawing.Point(6, 19)
        Me.SVPWMControl1.Name = "SVPWMControl1"
        Me.SVPWMControl1.Size = New System.Drawing.Size(301, 301)
        Me.SVPWMControl1.TabIndex = 221
        Me.ToolTip1.SetToolTip(Me.SVPWMControl1, "SVPWM model")
        Me.SVPWMControl1.TrackBar = 0.0!
        Me.SVPWMControl1.VoltageVector = 0
        '
        'PWM1_actual
        '
        Me.PWM1_actual.ADCpoint1 = 0.0!
        Me.PWM1_actual.ADCpoint2 = 0.0!
        Me.PWM1_actual.BackColor = System.Drawing.Color.White
        Me.PWM1_actual.Location = New System.Drawing.Point(10, 33)
        Me.PWM1_actual.Name = "PWM1_actual"
        Me.PWM1_actual.Size = New System.Drawing.Size(200, 30)
        Me.PWM1_actual.TabIndex = 231
        Me.PWM1_actual.X1 = 0.0!
        Me.PWM1_actual.X2 = 0.0!
        '
        'PWM2_actual
        '
        Me.PWM2_actual.ADCpoint1 = 0.0!
        Me.PWM2_actual.ADCpoint2 = 0.0!
        Me.PWM2_actual.BackColor = System.Drawing.Color.White
        Me.PWM2_actual.Location = New System.Drawing.Point(10, 78)
        Me.PWM2_actual.Name = "PWM2_actual"
        Me.PWM2_actual.Size = New System.Drawing.Size(200, 30)
        Me.PWM2_actual.TabIndex = 232
        Me.PWM2_actual.X1 = 0.0!
        Me.PWM2_actual.X2 = 0.0!
        '
        'PWM3_actual
        '
        Me.PWM3_actual.ADCpoint1 = 0.0!
        Me.PWM3_actual.ADCpoint2 = 0.0!
        Me.PWM3_actual.BackColor = System.Drawing.Color.White
        Me.PWM3_actual.Location = New System.Drawing.Point(10, 123)
        Me.PWM3_actual.Name = "PWM3_actual"
        Me.PWM3_actual.Size = New System.Drawing.Size(200, 30)
        Me.PWM3_actual.TabIndex = 233
        Me.PWM3_actual.X1 = 0.0!
        Me.PWM3_actual.X2 = 0.0!
        '
        'PWM3_virtual
        '
        Me.PWM3_virtual.ADCpoint1 = 0.0!
        Me.PWM3_virtual.ADCpoint2 = 0.0!
        Me.PWM3_virtual.BackColor = System.Drawing.Color.White
        Me.PWM3_virtual.Location = New System.Drawing.Point(12, 123)
        Me.PWM3_virtual.Name = "PWM3_virtual"
        Me.PWM3_virtual.Size = New System.Drawing.Size(200, 30)
        Me.PWM3_virtual.TabIndex = 224
        Me.PWM3_virtual.X1 = 0.0!
        Me.PWM3_virtual.X2 = 0.0!
        '
        'PWM1_virtual
        '
        Me.PWM1_virtual.ADCpoint1 = 0.0!
        Me.PWM1_virtual.ADCpoint2 = 0.0!
        Me.PWM1_virtual.BackColor = System.Drawing.Color.White
        Me.PWM1_virtual.Location = New System.Drawing.Point(12, 33)
        Me.PWM1_virtual.Name = "PWM1_virtual"
        Me.PWM1_virtual.Size = New System.Drawing.Size(200, 30)
        Me.PWM1_virtual.TabIndex = 222
        Me.PWM1_virtual.X1 = 0.0!
        Me.PWM1_virtual.X2 = 0.0!
        '
        'PWM2_virtual
        '
        Me.PWM2_virtual.ADCpoint1 = 0.0!
        Me.PWM2_virtual.ADCpoint2 = 0.0!
        Me.PWM2_virtual.BackColor = System.Drawing.Color.White
        Me.PWM2_virtual.Location = New System.Drawing.Point(12, 78)
        Me.PWM2_virtual.Name = "PWM2_virtual"
        Me.PWM2_virtual.Size = New System.Drawing.Size(200, 30)
        Me.PWM2_virtual.TabIndex = 223
        Me.PWM2_virtual.X1 = 0.0!
        Me.PWM2_virtual.X2 = 0.0!
        '
        'TextBoxOmegaFltrCoef
        '
        Me.TextBoxOmegaFltrCoef.AllowNegative = True
        Me.TextBoxOmegaFltrCoef.AllowSpace = False
        Me.TextBoxOmegaFltrCoef.Location = New System.Drawing.Point(124, 58)
        Me.TextBoxOmegaFltrCoef.Name = "TextBoxOmegaFltrCoef"
        Me.TextBoxOmegaFltrCoef.Size = New System.Drawing.Size(91, 20)
        Me.TextBoxOmegaFltrCoef.TabIndex = 341
        '
        'TextBoxSMCMaxError
        '
        Me.TextBoxSMCMaxError.AllowNegative = True
        Me.TextBoxSMCMaxError.AllowSpace = False
        Me.TextBoxSMCMaxError.Location = New System.Drawing.Point(124, 32)
        Me.TextBoxSMCMaxError.Name = "TextBoxSMCMaxError"
        Me.TextBoxSMCMaxError.Size = New System.Drawing.Size(91, 20)
        Me.TextBoxSMCMaxError.TabIndex = 336
        '
        'TextBoxSMCgain
        '
        Me.TextBoxSMCgain.AllowNegative = True
        Me.TextBoxSMCgain.AllowSpace = False
        Me.TextBoxSMCgain.Location = New System.Drawing.Point(124, 6)
        Me.TextBoxSMCgain.Name = "TextBoxSMCgain"
        Me.TextBoxSMCgain.Size = New System.Drawing.Size(91, 20)
        Me.TextBoxSMCgain.TabIndex = 335
        '
        'TextBoxmH
        '
        Me.TextBoxmH.AllowNegative = True
        Me.TextBoxmH.AllowSpace = False
        Me.TextBoxmH.Location = New System.Drawing.Point(124, 111)
        Me.TextBoxmH.Name = "TextBoxmH"
        Me.TextBoxmH.Size = New System.Drawing.Size(91, 20)
        Me.TextBoxmH.TabIndex = 293
        '
        'TextBoxmOhm
        '
        Me.TextBoxmOhm.AllowNegative = True
        Me.TextBoxmOhm.AllowSpace = False
        Me.TextBoxmOhm.Location = New System.Drawing.Point(124, 85)
        Me.TextBoxmOhm.Name = "TextBoxmOhm"
        Me.TextBoxmOhm.Size = New System.Drawing.Size(91, 20)
        Me.TextBoxmOhm.TabIndex = 290
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(821, 737)
        Me.Controls.Add(Me.ButtonCOM)
        Me.Controls.Add(Me.ButtonLog)
        Me.Controls.Add(Me.ButtonScope)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.TabControlFOC)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Main"
        Me.Text = "FOC tool"
        Me.TabControlFOC.ResumeLayout(False)
        Me.TabQDPI.ResumeLayout(False)
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.TrackBarQKi, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBarQ_SP, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBarQKp, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.TrackBarDKi, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBarD_SP, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBarDKp, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabSpeedPID.ResumeLayout(False)
        Me.GroupBox10.ResumeLayout(False)
        Me.GroupBox10.PerformLayout()
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        CType(Me.TrackBarSpeedSP, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBarSpeedKd, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBarSpeedKi, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBarSpeedKp, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabVectorConrol.ResumeLayout(False)
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.TabParameters.ResumeLayout(False)
        Me.TabParameters.PerformLayout()
        CType(Me.TrackBarTest3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBarTest4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBarTest1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBarTest2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents SerialPort1 As System.IO.Ports.SerialPort
    Friend WithEvents VectorControlTimer As System.Windows.Forms.Timer
    Friend WithEvents TabControlFOC As System.Windows.Forms.TabControl
    Friend WithEvents TabVectorConrol As System.Windows.Forms.TabPage
    Friend WithEvents CheckBoxSync As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBoxAutoRotate As System.Windows.Forms.CheckBox
    Friend WithEvents LabelC As System.Windows.Forms.Label
    Friend WithEvents LabelB As System.Windows.Forms.Label
    Friend WithEvents LabelA As System.Windows.Forms.Label
    Friend WithEvents PWM3_virtual As FOCinterface.PWMControl
    Friend WithEvents PWM2_virtual As FOCinterface.PWMControl
    Friend WithEvents PWM1_virtual As FOCinterface.PWMControl
    Friend WithEvents SVPWMControl1 As FOCinterface.SVPWMControl
    Friend WithEvents TabSpeedPID As System.Windows.Forms.TabPage
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents LabelSpeedKd As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents LabelSpeedKi As System.Windows.Forms.Label
    Friend WithEvents LabelSpeedKp As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents ValueLabelSpeedSP As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents LabelRPM As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents LabelTemp As System.Windows.Forms.Label
    Friend WithEvents LabelMode As System.Windows.Forms.Label
    Friend WithEvents LabelPower As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents TabParameters As System.Windows.Forms.TabPage
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents LabelG As System.Windows.Forms.Label
    Friend WithEvents LabelF As System.Windows.Forms.Label
    Friend WithEvents TextBoxmH As FOCinterface.NumericTextBox
    Friend WithEvents TextBoxmOhm As FOCinterface.NumericTextBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents LabelPeriodTime As System.Windows.Forms.Label
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuItemOpen As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuItemSave As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents MenuItemExit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuItemSettings As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RadioButtonSensorless As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButtonQEI As System.Windows.Forms.RadioButton
    Friend WithEvents LabelTest3 As System.Windows.Forms.Label
    Friend WithEvents TrackBarTest3 As System.Windows.Forms.TrackBar
    Friend WithEvents LabelTest4 As System.Windows.Forms.Label
    Friend WithEvents TrackBarTest4 As System.Windows.Forms.TrackBar
    Friend WithEvents LabelTest1 As System.Windows.Forms.Label
    Friend WithEvents TrackBarTest1 As System.Windows.Forms.TrackBar
    Friend WithEvents LabelTest2 As System.Windows.Forms.Label
    Friend WithEvents TrackBarTest2 As System.Windows.Forms.TrackBar
    Friend WithEvents TabQDPI As System.Windows.Forms.TabPage
    Friend WithEvents LabelDKi As System.Windows.Forms.Label
    Friend WithEvents LabelDKp As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents LabelQKi As System.Windows.Forms.Label
    Friend WithEvents LabelQKp As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents PWM3_actual As FOCinterface.PWMControl
    Friend WithEvents PWM2_actual As FOCinterface.PWMControl
    Friend WithEvents PWM1_actual As FOCinterface.PWMControl
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents ButtonScope As System.Windows.Forms.Button
    Friend WithEvents ToolsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddScopeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DataloggerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ButtonLog As System.Windows.Forms.Button
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents FixedPointToolToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ProgressControlSpeedDer As FOCinterface.ProgressControl
    Friend WithEvents ProgressControlSpeedInt As FOCinterface.ProgressControl
    Friend WithEvents ProgressControlSpeedErr As FOCinterface.ProgressControl
    Friend WithEvents RadioButtonManualSpeed As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButtonAutoSpeed As System.Windows.Forms.RadioButton
    Friend WithEvents ButtonDivR As System.Windows.Forms.Button
    Friend WithEvents ButtonDivL As System.Windows.Forms.Button
    Friend WithEvents ButtonCOM As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents TextBoxOmegaFltrCoef As FOCinterface.NumericTextBox
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents TextBoxSMCMaxError As FOCinterface.NumericTextBox
    Friend WithEvents TextBoxSMCgain As FOCinterface.NumericTextBox
    Friend WithEvents CheckBoxTransmit As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents LabelD_SP As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents LabelQ_SP As System.Windows.Forms.Label
    Friend WithEvents TrackBarD_SP As Trackbar.TransparentTrackBar
    Friend WithEvents TrackBarQKi As Trackbar.TransparentTrackBar
    Friend WithEvents TrackBarQ_SP As Trackbar.TransparentTrackBar
    Friend WithEvents TrackBarQKp As Trackbar.TransparentTrackBar
    Friend WithEvents TrackBarDKi As Trackbar.TransparentTrackBar
    Friend WithEvents TrackBarDKp As Trackbar.TransparentTrackBar
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents VectorViewer1 As FOCinterface.VectorViewer
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents ProgressControl4 As FOCinterface.ProgressControl
    Friend WithEvents ProgressControl3 As FOCinterface.ProgressControl
    Friend WithEvents ProgressControl2 As FOCinterface.ProgressControl
    Friend WithEvents ProgressControl1 As FOCinterface.ProgressControl
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents TrackBarSpeedKd As Trackbar.TransparentTrackBar
    Friend WithEvents TrackBarSpeedKi As Trackbar.TransparentTrackBar
    Friend WithEvents TrackBarSpeedKp As Trackbar.TransparentTrackBar
    Friend WithEvents TrackBarSpeedSP As Trackbar.TransparentTrackBar
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox10 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
