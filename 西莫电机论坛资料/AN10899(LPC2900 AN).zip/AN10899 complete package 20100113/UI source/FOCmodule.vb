﻿Imports System.CodeDom

Module FOCmodule

    'Public Class Item
    '    Public Property Type() As DataType
    '        Get
    '            Return typeValue
    '        End Get
    '        Set(ByVal value As DataType)
    '            typeValue = value
    '        End Set
    '    End Property
    '    Private typeValue As DataType

    '    Public Property TxChar() As Char
    '        Get
    '            Return txCharValue
    '        End Get
    '        Set(ByVal value As Char)
    '            txCharValue = value
    '        End Set
    '    End Property
    '    Private txCharValue As Char

    '    Public Property IntBits() As Integer
    '        Get
    '            Return IntBits
    '        End Get
    '        Set(ByVal value As Integer)
    '            intBitsValue = value
    '        End Set
    '    End Property
    '    Private intBitsValue As Integer

    '    Public Property FractBits() As Integer
    '        Get
    '            Return FractBits
    '        End Get
    '        Set(ByVal value As Integer)
    '            fractBitsValue = value
    '        End Set
    '    End Property
    '    Private fractBitsValue As Integer

    '    Public Sub New(ByVal type As DataType, ByVal txChar As Char)
    '        typeValue = type
    '        txCharValue = txChar
    '    End Sub

    '    Public Sub New(ByVal type As DataType, ByVal txChar As Char, ByVal intBits As Integer, ByVal fractBits As Integer)
    '        typeValue = type
    '        txCharValue = txChar
    '        intBitsValue = intBits
    '        fractBitsValue = fractBits
    '    End Sub

    '    Public ReadOnly Property ToBytes() As Byte()
    '        Get
    '            If Me.Type <> DataType.WORD Or Me.Type <> DataType.DWORD Then
    '                Throw New Exception("")
    '            End If
    '            Return Nothing
    '        End Get
    '    End Property

    'End Class

    'Public Enum DataType
    '    BOOL
    '    WORD
    '    DWORD
    '    BYTE_
    '    FixedPoint
    'End Enum

    'Public Enum FieldNames
    '    enabled         ' FOC enabled/disabled
    '    alpha           ' Measured / calculated stator angle
    '    adcVal          ' ADC values measured
    '    currentOffset   ' Current offset
    '    adcPoint        ' ADC start offset from t=0
    '    adcSeq          ' ADC sequence
    '    temp
    '    busy            ' FOC busy
    '    sector          ' Current SVWPWM sector
    '    pwm             ' PWM values from space vector
    '    mACT            ' Match activate registers for PWM 
    '    mDACT           ' Match de-activate registers for PWM  
    '    Ia              ' Reconstructed Ia	
    '    Ib              ' Reconstructed Ib	
    '    Ic              ' Reconstructed Ic
    '    Ialpha          ' Calculated Ia in dynamic reference frame
    '    Ibeta           ' Calculated Ib in dynamic reference frame
    '    Id              ' Calculated Id in static reference frame
    '    Iq              ' Calculated Iq in static reference frame
    '    Vd              ' Regulated PI output d in static reference frame
    '    Vq              ' Regulated PI output q in static reference frame
    '    Valpha          ' Regulated PI output alpha in dynamic reference frame
    '    Vbeta           ' Regulated PI output beta in dynamic reference frame
    '    Vr1             ' Vref1 from inverse park
    '    Vr2             ' Vref2 from inverse park
    '    Vr3             ' Vref3 from inverse park
    '    Q_err           ' Q error
    '    Q_int           ' Q integrated error
    '    Q_SP            '  SetPoint Q
    '    Q_Kp            ' VQ Kp
    '    Q_Ki            ' VQ Ki
    '    D_SP            ' SetPoint D
    '    D_err           ' D error
    '    D_int           ' D integrated error
    '    D_Kp            ' VD PI const Kp
    '    D_Ki            ' VD PI const Ki	 	
    '    speed           ' Speed : 32 <> 10000 RPM fixed point
    '    speed_err       ' Speed error
    '    speed_int       ' Speed integrated error
    '    speed_der       ' Speed derrivated error
    '    speed_prev_err  ' Speed previous error value
    '    speed_Kp        ' Speed Kp
    '    speed_Ki        ' Speed Ki
    '    speed_Kd        ' Speed Kd
    '    speed_SP        ' Speed setpoint
    '    alphaCalc
    '    alphaEst

    '    sEalpha        ' Variable: Stationary alfa-axis back EMF 
    '    sEalphaFinal   ' Variable: Filtered EMF for Angle calculation
    '    sZalpha        ' Output: Stationary alfa-axis sliding control 
    '    sGsmopos       ' Parameter: Motor dependent control gain 
    '    sEstIalpha     ' Variable: Estimated stationary alfa-axis stator current 
    '    sFsmopos       ' Parameter: Motor dependent plant matrix 
    '    sEbeta         ' Variable: Stationary beta-axis back EMF 
    '    sEbetaFinal    ' Variable: Filtered EMF for Angle calculation
    '    sZbeta         ' Output: Stationary beta-axis sliding control 
    '    sEstIbeta      ' Variable: Estimated stationary beta-axis stator current 
    '    sIalphaError   ' Variable: Stationary alfa-axis current error                 
    '    sKslide        ' Parameter: Sliding control gain 
    '    sMaxSMCError   ' Parameter: Maximum current error for linear SMC 
    '    sIbetaError    ' Variable: Stationary beta-axis current error                 
    '    sKslf          ' Parameter: Sliding control filter gain 
    '    sKslfFinal     ' Parameter: BEMF Filter for angle calculation
    '    sFiltOmCoef    ' Parameter: Filter Coef for Omega filtered calc
    '    sThetaOffset   ' Output: Offset used to compensate rotor angle
    '    sTheta         ' Output: Compensated rotor angle 
    '    sOmega         ' Output: Rotor speed
    '    sOmegaFltred   ' Output: Filtered Rotor speed for speed PI
    '    test1
    '    test2
    '    test3
    '    test4
    '    mode
    '    empty1
    '    empty2
    '    empty3
    '    sVbeta
    '    sValpha
    '    sIbeta
    '    sIalpha
    '    alphaError
    'End Enum

    'Public Sub MakeFOCItemList()
    '    Dim FOCparams As New Dictionary(Of FieldNames, Item)
    '    FOCparams.Add(FieldNames.adcPoint, New Item(FieldNames.adcPoint, DataType.FixedPoint, "c"c, 6, 10))
    '    FOCparams.Item(FieldNames.adcPoint).FractBits = 10

    '    'FOCItemlist.GetItem(FieldNames.adcPoint).ToSingle()
    'End Sub

End Module
