﻿Imports System.Drawing.Drawing2D

Public Class AboutForm

    Protected Overrides Sub OnPaint(ByVal e As System.Windows.Forms.PaintEventArgs)
        MyBase.OnPaint(e)

        Dim col1 As System.Drawing.Color = System.Drawing.ColorTranslator.FromHtml("#BCCFE8")
        Dim col2 As System.Drawing.Color = System.Drawing.ColorTranslator.FromHtml("#5886C4")

        Dim lgb As New LinearGradientBrush(New Point(0, 64), New Point(0, Me.Height), _
           col1, _
           col2)
        e.Graphics.FillRectangle(lgb, 0, 64, Me.Width, Me.Height)

    End Sub
End Class