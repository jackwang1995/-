﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ScopeForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ScopeForm))
        Me.Label20 = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.CheckBoxSignalAuto = New System.Windows.Forms.CheckBox
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.ListBoxSignal1 = New System.Windows.Forms.ListBox
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.ListBoxSignal2 = New System.Windows.Forms.ListBox
        Me.TextBoxSignalMin = New FOCinterface.NumericTextBox
        Me.TextBoxSignalMax = New FOCinterface.NumericTextBox
        Me.ScrollControl1 = New FOCinterface.ScrollControl
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(673, 9)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(27, 13)
        Me.Label20.TabIndex = 310
        Me.Label20.Text = "Max"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(673, 35)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(24, 13)
        Me.Label19.TabIndex = 309
        Me.Label19.Text = "Min"
        '
        'CheckBoxSignalAuto
        '
        Me.CheckBoxSignalAuto.AutoSize = True
        Me.CheckBoxSignalAuto.Checked = True
        Me.CheckBoxSignalAuto.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBoxSignalAuto.Location = New System.Drawing.Point(676, 58)
        Me.CheckBoxSignalAuto.Name = "CheckBoxSignalAuto"
        Me.CheckBoxSignalAuto.Size = New System.Drawing.Size(75, 17)
        Me.CheckBoxSignalAuto.TabIndex = 308
        Me.CheckBoxSignalAuto.Text = "Autorange"
        Me.CheckBoxSignalAuto.UseVisualStyleBackColor = True
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Location = New System.Drawing.Point(6, 5)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(128, 150)
        Me.TabControl1.TabIndex = 313
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.ListBoxSignal1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(120, 124)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Channel 1"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'ListBoxSignal1
        '
        Me.ListBoxSignal1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListBoxSignal1.FormattingEnabled = True
        Me.ListBoxSignal1.Location = New System.Drawing.Point(3, 3)
        Me.ListBoxSignal1.Name = "ListBoxSignal1"
        Me.ListBoxSignal1.Size = New System.Drawing.Size(114, 108)
        Me.ListBoxSignal1.TabIndex = 312
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.ListBoxSignal2)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(120, 124)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Channel 2"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'ListBoxSignal2
        '
        Me.ListBoxSignal2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListBoxSignal2.FormattingEnabled = True
        Me.ListBoxSignal2.Location = New System.Drawing.Point(3, 3)
        Me.ListBoxSignal2.Name = "ListBoxSignal2"
        Me.ListBoxSignal2.Size = New System.Drawing.Size(114, 108)
        Me.ListBoxSignal2.TabIndex = 313
        '
        'TextBoxSignalMin
        '
        Me.TextBoxSignalMin.AllowNegative = True
        Me.TextBoxSignalMin.AllowSpace = False
        Me.TextBoxSignalMin.Location = New System.Drawing.Point(703, 32)
        Me.TextBoxSignalMin.Name = "TextBoxSignalMin"
        Me.TextBoxSignalMin.Size = New System.Drawing.Size(59, 20)
        Me.TextBoxSignalMin.TabIndex = 307
        '
        'TextBoxSignalMax
        '
        Me.TextBoxSignalMax.AllowNegative = True
        Me.TextBoxSignalMax.AllowSpace = False
        Me.TextBoxSignalMax.Location = New System.Drawing.Point(703, 6)
        Me.TextBoxSignalMax.Name = "TextBoxSignalMax"
        Me.TextBoxSignalMax.Size = New System.Drawing.Size(59, 20)
        Me.TextBoxSignalMax.TabIndex = 306
        '
        'ScrollControl1
        '
        Me.ScrollControl1.Auto = True
        Me.ScrollControl1.BackColor = System.Drawing.Color.White
        Me.ScrollControl1.Location = New System.Drawing.Point(136, 6)
        Me.ScrollControl1.Max = -1.0E+7!
        Me.ScrollControl1.Min = 1.0E+7!
        Me.ScrollControl1.Mode = FOCinterface.ScrollControl.ModeEnum.ShiftOnValue
        Me.ScrollControl1.Name = "ScrollControl1"
        Me.ScrollControl1.Size = New System.Drawing.Size(533, 147)
        Me.ScrollControl1.Speed = 10000
        Me.ScrollControl1.TabIndex = 302
        Me.ScrollControl1.Value1Color = System.Drawing.Color.Blue
        Me.ScrollControl1.Value2Color = System.Drawing.Color.Red
        Me.ScrollControl1.Value2Enabled = True
        '
        'ScopeForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(766, 158)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.CheckBoxSignalAuto)
        Me.Controls.Add(Me.TextBoxSignalMin)
        Me.Controls.Add(Me.TextBoxSignalMax)
        Me.Controls.Add(Me.ScrollControl1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "ScopeForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Scope"
        Me.TopMost = True
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents CheckBoxSignalAuto As System.Windows.Forms.CheckBox
    Friend WithEvents TextBoxSignalMin As FOCinterface.NumericTextBox
    Friend WithEvents TextBoxSignalMax As FOCinterface.NumericTextBox
    Friend WithEvents ScrollControl1 As FOCinterface.ScrollControl
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents ListBoxSignal1 As System.Windows.Forms.ListBox
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents ListBoxSignal2 As System.Windows.Forms.ListBox
End Class
